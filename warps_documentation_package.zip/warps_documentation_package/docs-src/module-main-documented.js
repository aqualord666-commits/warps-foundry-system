/**
 * @file main.js
 * @description Entry point of WARPS System for Foundry VTT.
 * The module registers custom Actor data model and Actor Sheet for character documents.
 */

/**
 * Character statistic keys used by the WARPS character sheet.
 * @constant {string[]}
 */
const WARPS_STAT_KEYS = ["str", "foc", "ref", "per", "int", "dex", "end"];

/**
 * Progression resource keys displayed on the character sheet.
 * @constant {string[]}
 */
const WARPS_PROGRESS_KEYS = ["universalPoints", "combatPoints", "narrativePoints"];

/**
 * Calculate derived bounds for character resources.
 * HP depends on Strength, EFF depends on Endurance.
 *
 * @param {object} system - Actor system data object.
 * @param {object} system.stats - Character statistics.
 * @param {object} system.resources - Character resources.
 * @returns {object} Object with hp and eff resource bounds.
 */
function getWarpsResourceBounds(system) {
  const strength = Math.max(system.stats?.str ?? 0, 0);
  const endurance = Math.max(system.stats?.end ?? 0, 0);
  const maxHp = strength * 5;
  const minHp = -maxHp;
  const hpValue = system.resources?.hp?.value;
  const effValue = system.resources?.eff?.value ?? 0;

  return {
    hp: {
      min: minHp,
      max: maxHp,
      value: hpValue == null ? maxHp : Math.clamp(hpValue, minHp, maxHp)
    },
    eff: {
      min: 0,
      max: endurance,
      value: Math.clamp(effValue, 0, endurance)
    }
  };
}

/**
 * TypeDataModel describing the WARPS character data schema.
 * The schema contains base statistics, resources and progression points.
 * @extends foundry.abstract.TypeDataModel
 */
class WarpsCharacterData extends foundry.abstract.TypeDataModel {
  /**
   * Define system data schema for the character Actor type.
   * @returns {object} Foundry data schema.
   */
  static defineSchema() {
    // Implementation is stored in the repository file module/main.js.
  }

  /**
   * Prepare calculated fields and clamp resource values.
   * Called by Foundry during document data preparation.
   * @returns {void}
   */
  prepareDerivedData() {
    const resourceBounds = getWarpsResourceBounds(this);
    this.resources.eff.value = resourceBounds.eff.value;
    this.resources.hp.value = resourceBounds.hp.value;
  }
}

/**
 * Character sheet UI for the WARPS Actor type.
 * Uses Handlebars template templates/actor/character-sheet.hbs.
 * @extends foundry.applications.sheets.ActorSheetV2
 */
class WarpsCharacterSheet extends WarpsSheetMixin(WarpsActorSheetBase) {
  /**
   * Prepare template context for rendering statistics and progression fields.
   * @param {object} options - Sheet render options.
   * @returns {Promise<object>} Context for Handlebars template.
   */
  async _prepareContext(options) {
    // Implementation is stored in the repository file module/main.js.
  }
}
