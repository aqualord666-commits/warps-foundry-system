# WARPS System Wiki

WARPS System — пользовательская RPG-система для Foundry Virtual Tabletop.

## Основные возможности

- создание персонажа типа `character`;
- заполнение характеристик персонажа;
- отображение ресурсов HP и EFF;
- учет очков прогрессии;
- поддержка русской и английской локализации.

## Разделы

- [Установка](Installation.md)
- [Создание персонажа](Creating-Character.md)
- [Лист персонажа](Character-Sheet.md)
- [Характеристики и ресурсы](Stats-and-Resources.md)
- [FAQ](FAQ.md)
