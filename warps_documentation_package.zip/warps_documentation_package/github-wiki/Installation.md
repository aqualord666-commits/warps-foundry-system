# Установка WARPS System

1. Открыть папку пользовательских данных Foundry VTT.
2. Перейти в каталог `Data/systems`.
3. Склонировать репозиторий:

```bash
git clone https://github.com/aqualord666-commits/warps-foundry-system.git warps
```

4. Перезапустить Foundry VTT.
5. При создании мира выбрать систему `Warps System`.

## Требования

- Foundry VTT версии 13 или выше.
- Современный браузер: Chrome, Edge или Firefox.
