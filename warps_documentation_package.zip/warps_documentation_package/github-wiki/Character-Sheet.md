# Лист персонажа

Лист персонажа состоит из трех основных блоков:

## Stats
Раздел характеристик. В нем вводятся числовые параметры персонажа: Strength, Focus, Reflex, Perception, Intellect, Dexterity, Endurance.

## Resources
Раздел ресурсов. Отображает текущие и предельные значения HP и EFF.

## Progression
Раздел прогрессии. Содержит очки развития: Universal Points, Combat Points, Narrative Points.
